const lista = () => { 
	return `
`
}
exports.lista = lista